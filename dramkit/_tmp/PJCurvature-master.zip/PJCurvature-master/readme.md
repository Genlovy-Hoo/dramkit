# Numerical solution for the line curvature

by : Peijin Zhang

Calculates the curvature using three points, written in Python and MATLAB


[中文文档](https://zhuanlan.zhihu.com/p/72083902)

English doc : doc/PJCurv.pdf
