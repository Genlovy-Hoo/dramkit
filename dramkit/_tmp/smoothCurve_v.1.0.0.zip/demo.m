x = 1:100;
A = cos(2*pi*0.05*x+2*pi*rand) + 0.5*randn(1,100);
B = smoothCurve(A);
plot(x,A,'-o',x,B,'-x')
legend('Original Data','Smoothed Data')