sorts
======

bubble_sort
------------

.. automodule:: dramkit.sorts.bubble_sort

.. currentmodule:: dramkit.sorts.bubble_sort

bubble_sort
^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.bubble_sort.bubble_sort

bucket_sort
------------

.. automodule:: dramkit.sorts.bucket_sort

.. currentmodule:: dramkit.sorts.bucket_sort

bucket_sort
^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.bucket_sort.bucket_sort

insert_sort
------------

.. automodule:: dramkit.sorts.insert_sort

.. currentmodule:: dramkit.sorts.insert_sort

insert_sort
^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort.insert_sort

insert_to_sorted
^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort.insert_to_sorted

rank_of_insert
^^^^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort.rank_of_insert

insert_sort_bin
----------------

.. automodule:: dramkit.sorts.insert_sort_bin

.. currentmodule:: dramkit.sorts.insert_sort_bin

bin_search
^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort_bin.bin_search

insert_sort_bin
^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort_bin.insert_sort_bin

rank_of_insert_bin
^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.sorts.insert_sort_bin.rank_of_insert_bin

quick_sort
-----------

.. automodule:: dramkit.sorts.quick_sort

.. currentmodule:: dramkit.sorts.quick_sort

quick_sort
^^^^^^^^^^^

.. autofunction:: dramkit.sorts.quick_sort.quick_sort
