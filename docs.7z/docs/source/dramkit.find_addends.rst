find_addends
=============

find_addends_backpack01float
-----------------------------

.. automodule:: dramkit.find_addends.find_addends_backpack01float

.. currentmodule:: dramkit.find_addends.find_addends_backpack01float

find_addends_backpack01float
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_backpack01float.find_addends_backpack01float

find_addends_backpack01int
---------------------------

.. automodule:: dramkit.find_addends.find_addends_backpack01int

.. currentmodule:: dramkit.find_addends.find_addends_backpack01int

find_addends_backpack01int
^^^^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_backpack01int.find_addends_backpack01int

find_addends_bigfirst
----------------------

.. automodule:: dramkit.find_addends.find_addends_bigfirst

.. currentmodule:: dramkit.find_addends.find_addends_bigfirst

find_addends_bigfirst
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_bigfirst.find_addends_bigfirst

find_addends_recu
------------------

.. automodule:: dramkit.find_addends.find_addends_recu

.. currentmodule:: dramkit.find_addends.find_addends_recu

find_addends_recu
^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_recu.find_addends_recu

find_addends_smlfirst
----------------------

.. automodule:: dramkit.find_addends.find_addends_smlfirst

.. currentmodule:: dramkit.find_addends.find_addends_smlfirst

find_addends_smlfirst
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_smlfirst.find_addends_smlfirst

find_addends_utils
-------------------

.. automodule:: dramkit.find_addends.find_addends_utils

.. currentmodule:: dramkit.find_addends.find_addends_utils

tol2side_x_eq_y
^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol2side_x_eq_y

tol_eq
^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol_eq

tol_x_big_y
^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol_x_big_y

tol_x_big_eq_y
^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol_x_big_eq_y

tol_x_sml_y
^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol_x_sml_y

tol_x_sml_eq_y
^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.tol_x_sml_eq_y

get_alts_sml
^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.get_alts_sml

backfind_sml1st_index
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.find_addends.find_addends_utils.backfind_sml1st_index
