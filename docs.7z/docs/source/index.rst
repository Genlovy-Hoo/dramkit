Welcome to DramKit's documentation!
====================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   dramkit <dramkit>
   backpacks <dramkit.backpacks>
   datsci <dramkit.datsci>
   find_addends <dramkit.find_addends>
   logtools <dramkit.logtools>
   optimizer <dramkit.optimizer>
   other <dramkit.other>
   plottools <dramkit.plottools>
   pystyles <dramkit.pystyles>
   sorts <dramkit.sorts>
   speedup <dramkit.speedup>
   sqltools <dramkit.sqltools>
   webtools <dramkit.webtools>

Indices and tables
===================

* :ref:`genindex`
* :ref:`modindex`
