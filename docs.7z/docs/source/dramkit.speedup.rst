speedup
========

multi_process
--------------

.. automodule:: dramkit.speedup.multi_process

.. currentmodule:: dramkit.speedup.multi_process

multi_process_concurrent
^^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.speedup.multi_process.multi_process_concurrent

multi_thread
-------------

.. automodule:: dramkit.speedup.multi_thread

.. currentmodule:: dramkit.speedup.multi_thread

MultiThread
^^^^^^^^^^^^

.. autoclass:: dramkit.speedup.multi_thread.MultiThread
    :members:
    :undoc-members:
    :show-inheritance:

multi_thread_threading
^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.speedup.multi_thread.multi_thread_threading

multi_thread_concurrent
^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.speedup.multi_thread.multi_thread_concurrent
