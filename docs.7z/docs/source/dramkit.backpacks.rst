backpacks
==========

backpack01_float_dy
--------------------

.. automodule:: dramkit.backpacks.backpack01_float_dy

.. currentmodule:: dramkit.backpacks.backpack01_float_dy

backpack01_float_dy
^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_float_dy.backpack01_float_dy

backpack01_float_dy_smp
^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_float_dy.backpack01_float_dy_smp

backpack01_int_dy
------------------

.. automodule:: dramkit.backpacks.backpack01_int_dy

.. currentmodule:: dramkit.backpacks.backpack01_int_dy

backpack01_int_dy
^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_int_dy.backpack01_int_dy

backpack01_int_dy_smp
^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_int_dy.backpack01_int_dy_smp

backpack01_float_dy
^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_int_dy.backpack01_float_dy

backpack01_float_dy_smp
^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.backpacks.backpack01_int_dy.backpack01_float_dy_smp
