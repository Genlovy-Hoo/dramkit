webtools
=========

utils_html
-----------

.. automodule:: dramkit.webtools.utils_html

.. currentmodule:: dramkit.webtools.utils_html

get_browser_path
^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.get_browser_path

open_html
^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.open_html

html_to_soup
^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.html_to_soup

soup_to_html
^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.soup_to_html

insert_src_head_end
^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.insert_src_head_end

del_js_head_end
^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.del_js_head_end

get_head_num
^^^^^^^^^^^^^

.. autofunction:: dramkit.webtools.utils_html.get_head_num
