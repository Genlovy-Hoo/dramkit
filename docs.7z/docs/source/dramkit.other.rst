other
======

othertools
-----------

.. automodule:: dramkit.other.othertools

.. currentmodule:: dramkit.other.othertools

archive_data
^^^^^^^^^^^^^

.. autofunction:: dramkit.other.othertools.archive_data

get_csv_df_colmaxmin
^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.other.othertools.get_csv_df_colmaxmin

load_text_multi
^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.other.othertools.load_text_multi

install_pkg
^^^^^^^^^^^^

.. autofunction:: dramkit.other.othertools.install_pkg

replace_endblank
-----------------

.. automodule:: dramkit.other.replace_endblank

.. currentmodule:: dramkit.other.replace_endblank

replace_endblank_in_file
^^^^^^^^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.other.replace_endblank.replace_endblank_in_file
