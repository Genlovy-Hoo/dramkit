pystyles
=========

dramkit_style
--------------

.. automodule:: dramkit.pystyles.dramkit_style

.. currentmodule:: dramkit.pystyles.dramkit_style

DramkitClassStyle
^^^^^^^^^^^^^^^^^^

.. autoclass:: dramkit.pystyles.dramkit_style.DramkitClassStyle
    :members:
    :undoc-members:
    :show-inheritance:

dramkit_funcsytle
^^^^^^^^^^^^^^^^^^

.. autofunction:: dramkit.pystyles.dramkit_style.dramkit_funcsytle
