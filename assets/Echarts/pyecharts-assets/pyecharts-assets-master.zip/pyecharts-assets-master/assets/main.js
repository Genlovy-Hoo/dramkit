define(["require", "exports"], function (require, exports) {
    "use strict";
    Object.defineProperty(exports, "__esModule", { value: true });
    function load_ipython_extension() {
        console.log("pyecharts-assert extension has been loaded");
    }
    exports.load_ipython_extension = load_ipython_extension;
});
